export const WHATSAPP_PHONE = "201515362792";
export const WHATSAPP_USERNAME = "karimalaa94";
export const INSTAGRAM = "https://instagram.com/darelbon";
export const FACEBOOK = "https://facebook.com/darelbonegypt/";
export const MAPS = [
  { name: "فرع 1", url: "https://maps.app.goo.gl/3p6UVN6TckfkUCkH8" },
  { name: "فرع 2", url: "https://maps.app.goo.gl/ev1JhyZhct2NHUhW8" },
];
export const ADDRESS = "[العنوان]";
export const HOURS = "[المواعيد]";